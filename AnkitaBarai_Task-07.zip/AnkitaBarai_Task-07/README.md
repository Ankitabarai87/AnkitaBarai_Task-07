# 🧺 Laundry Service Website (Responsive Design - Task 07)

This project is a **responsive laundry service landing page** built using **HTML5 and CSS3 (Flexbox)**. It includes a navigation bar and a hero section with a clean UI and responsive behavior across different screen sizes.

---

## ✨ Features

- 📌 Responsive Navigation Bar  
  - Logo on the left  
  - Menu links in the center  
  - Username on the right  

- 🎯 Hero Section  
  - Left: Heading, description, and CTA button  
  - Right: Laundry-themed image  

- 📱 Fully Responsive Design  
  - Tablet view adjustments  
  - Mobile view with hidden menu  
  - Column layout for small screens  

- 🎨 Interactive UI  
  - Hover effects on links and buttons  
  - Clean typography and spacing  

---

## 🛠️ Technologies Used

- HTML5  
- CSS3  
- Flexbox  
- Media Queries  

---

## 🎯 Concepts Practiced

- Flexbox layout (`display: flex`)  
- Responsive design using media queries  
- Viewport units (`vw`, `vh`)  
- Navigation bar structuring  
- Image and content alignment  
- Hover effects and UI styling  

---

## 📱 Responsive Breakpoints

- **Desktop** (1024px and above)
- **Tablet** (max-width: 1024px)
- **Mobile** (max-width: 768px)

---

## ▶️ How to Run

1. Clone or download this repository  
2. Open `index.html` in your browser  

---

## 🎓 Purpose

This project is part of a task to practice:
- Building responsive layouts  
- Using Flexbox effectively  
- Creating real-world UI designs  
- Handling layout issues across devices  

---

## 💡 Future Improvements

- Add hamburger menu for mobile navigation  
- Add animations and transitions  
- Connect with backend for real functionality  

